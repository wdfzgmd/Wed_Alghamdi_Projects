import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import java.time.LocalDate;
import java.util.ArrayList;

public class UserReservationPage extends Application {
    private String username;
    private ArrayList<Reservation> userReservations = new ArrayList<>();

    public UserReservationPage(String username) {
        this.username = username;
        System.out.println("Creating UserReservationPage for: " + username);
    }

    @Override
    public void start(Stage stage) {
        stage.setTitle("User Reservation Page - " + username);

        GridPane grid = new GridPane();
        grid.setPadding(new Insets(10));
        grid.setHgap(10);
        grid.setVgap(10);

        // Room selection
        ComboBox<Room> roomComboBox = new ComboBox<>();
        roomComboBox.getItems().addAll(Main.roomsList);
        roomComboBox.setPromptText("Select a room");

        // Custom cell factory to display room number
        roomComboBox.setCellFactory(param -> new ListCell<Room>() {
            @Override
            protected void updateItem(Room item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) {
                    setText(null);
                } else {
                    setText(item.getRoomNumber() + " (" + item.getClass().getSimpleName() + ")");
                }
            }
        });

        roomComboBox.setButtonCell(new ListCell<Room>() {
            @Override
            protected void updateItem(Room item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) {
                    setText(null);
                } else {
                    setText(item.getRoomNumber() + " (" + item.getClass().getSimpleName() + ")");
                }
            }
        });

        // Date picker
        DatePicker datePicker = new DatePicker();
        datePicker.setPromptText("Select date");
        datePicker.setValue(LocalDate.now());

        // Time selection
        ComboBox<String> timeComboBox = new ComboBox<>();
        timeComboBox.getItems().addAll(
                "08:00", "09:00", "10:00", "11:00",
                "12:00", "13:00", "14:00", "15:00", "16:00"
        );
        timeComboBox.setPromptText("Select time");

        Button requestButton = new Button("Request Reservation");
        Button viewHistoryButton = new Button("View My Reservations");
        Button refreshButton = new Button("Refresh Status");
        TextArea infoArea = new TextArea();
        infoArea.setEditable(false);

        grid.add(new Label("Room:"), 0, 0);
        grid.add(roomComboBox, 1, 0);
        grid.add(new Label("Date:"), 0, 1);
        grid.add(datePicker, 1, 1);
        grid.add(new Label("Time:"), 0, 2);
        grid.add(timeComboBox, 1, 2);
        grid.add(requestButton, 0, 3);
        grid.add(viewHistoryButton, 1, 3);
        grid.add(refreshButton, 0, 4);
        grid.add(infoArea, 0, 5, 2, 1);

        // Request reservation
        requestButton.setOnAction(e -> {
            Room selectedRoom = roomComboBox.getValue();
            LocalDate selectedDate = datePicker.getValue();
            String selectedTime = timeComboBox.getValue();

            if (selectedRoom == null || selectedDate == null || selectedTime == null) {
                infoArea.setText("Please fill all fields");
                return;
            }

            // Check if room is available at selected time
            int hour = Integer.parseInt(selectedTime.split(":")[0]);
            if (!selectedRoom.isAvailable(hour)) {
                infoArea.setText("Room is not available at selected time");
                return;
            }

            // Check for existing reservation at this time
            String dateTime = selectedDate.toString() + " " + selectedTime;

            // Make sure we have the latest reservations
            ArrayList<Reservation> currentReservations = ReservationManager.loadReservations();
            Main.reservationsList.clear();
            Main.reservationsList.addAll(currentReservations);

            boolean conflict = Main.reservationsList.stream()
                    .anyMatch(r -> r.getRoom().getRoomNumber().equals(selectedRoom.getRoomNumber()) &&
                            r.getDateTime().equals(dateTime) &&
                            (r.getStatus().equals("Approved") || r.getStatus().equals("Pending")));

            if (conflict) {
                infoArea.setText("This room is already reserved at selected time");
                return;
            }

            // Get the current user
            User currentUser = AccountManager.getUserByUsername(username);

            if (currentUser == null) {
                System.out.println("ERROR: User not found: " + username);
                System.out.println("Available users:");
                for (UserAccount acc : Main.usersList) {
                    System.out.println(" - " + acc.getUsername() + " (" + acc.getClass().getSimpleName() + ")");
                }

                // Create user if not found (this is just for demonstration - normally you'd handle this better)
                currentUser = new User(username, "pass", username, username + "@example.com");
                Main.usersList.add(currentUser);
                System.out.println("Created new user: " + currentUser.getUsername());
            }

            // Create new reservation
            Reservation newReservation = new Reservation(currentUser, selectedRoom, dateTime);
            System.out.println("Creating new reservation: " + newReservation);

            // Add reservation
            Main.reservationManager.addReservation(newReservation);

            infoArea.setText("Reservation request submitted successfully!\n" +
                    "Room: " + selectedRoom.getRoomNumber() + "\n" +
                    "Date: " + selectedDate + "\n" +
                    "Time: " + selectedTime + "\n" +
                    "Status: Pending approval");
        });

        // Function to display user's reservations
        Runnable showReservationHistory = () -> {
            // Load latest reservations from file
            ArrayList<Reservation> allReservations = Main.reservationManager.loadReservations();

            // Update in-memory list
            Main.reservationsList.clear();
            Main.reservationsList.addAll(allReservations);

            StringBuilder historyText = new StringBuilder();
            historyText.append("Your Reservation History:\n\n");

            boolean hasReservations = false;

            for (Reservation res : Main.reservationsList) {
                if (res.getUser().getUsername().equals(username)) {
                    hasReservations = true;
                    historyText.append("Room: ").append(res.getRoom().getRoomNumber()).append("\n")
                            .append("Date/Time: ").append(res.getDateTime()).append("\n")
                            .append("Status: ").append(res.getStatus()).append("\n");

                    if (!res.getComment().isEmpty()) {
                        historyText.append("Comment: ").append(res.getComment()).append("\n");
                    }
                    historyText.append("--------\n");
                }
            }

            if (!hasReservations) {
                historyText.append("You have no reservation history.");
            }

            infoArea.setText(historyText.toString());
        };

        // View reservation history
        viewHistoryButton.setOnAction(e -> showReservationHistory.run());

        // Refresh status button
        refreshButton.setOnAction(e -> showReservationHistory.run());

        // Show initial reservation status
        showReservationHistory.run();

        Scene scene = new Scene(grid, 500, 400);
        stage.setScene(scene);
        stage.show();
    }
}