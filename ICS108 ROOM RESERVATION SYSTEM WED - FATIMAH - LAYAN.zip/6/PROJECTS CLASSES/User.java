import java.util.ArrayList;

public class User extends UserAccount {
    private ArrayList<Reservation> reservationHistory;

    public User(String username, String password, String name, String email) {
        super(username, password, name, email);
        this.reservationHistory = new ArrayList<>();
    }

    public void addReservation(Reservation reservation) {
        reservationHistory.add(reservation);
    }

    public ArrayList<Reservation> getReservationHistory() {
        return reservationHistory;
    }
}