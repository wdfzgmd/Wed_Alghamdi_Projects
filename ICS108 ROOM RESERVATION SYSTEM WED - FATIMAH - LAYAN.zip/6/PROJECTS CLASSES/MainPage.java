import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

public class MainPage extends Application {

    @Override
    public void start(Stage primaryStage) {
        Label titleLabel = new Label("KFUPM's Room Reservation");

        Button adminBtn = new Button("Admin Login");
        Button userBtn = new Button("User Login");
        Button signUpBtn = new Button("User Sign Up");

        GridPane grid = new GridPane();
        grid.setPadding(new Insets(20));
        grid.setHgap(20);
        grid.setVgap(20);

        grid.add(titleLabel, 0, 0, 3, 1);
        grid.add(adminBtn, 0, 1);
        grid.add(userBtn, 1, 1);
        grid.add(signUpBtn, 2, 1);

        adminBtn.setOnAction(e -> {
            AdminLoginPage adminPage = new AdminLoginPage();
            try {
                adminPage.start(new Stage());
                primaryStage.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });

        userBtn.setOnAction(e -> {
            UserLoginPage userPage = new UserLoginPage();
            try {
                userPage.start(new Stage());
                primaryStage.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });

        signUpBtn.setOnAction(e -> {
            UserSignUpPage signUpPage = new UserSignUpPage();

            try {
                signUpPage.start(new Stage());
                primaryStage.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });

        Scene scene = new Scene(grid, 500, 250);
        primaryStage.setTitle("Main Page");
        primaryStage.setScene(scene);
        primaryStage.show();
    }
}

