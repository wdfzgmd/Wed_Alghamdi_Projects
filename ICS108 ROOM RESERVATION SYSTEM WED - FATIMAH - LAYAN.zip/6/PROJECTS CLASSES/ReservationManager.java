import java.io.*;
import java.util.*;

public class ReservationManager {
    private static final String FILE_NAME = "reservations.txt";

    public static String toFileString(Reservation res) {
        return res.getUser().getUsername() + "," +
                res.getRoom().getRoomNumber() + "," +
                res.getDateTime() + "," +
                res.getStatus() + "," +
                res.getComment();
    }

    public static void saveAllReservations(ArrayList<Reservation> reservations) {
        File file = FileUtils.getFile(FILE_NAME);

        try (PrintWriter pw = new PrintWriter(new FileOutputStream(file))) {
            for (Reservation res : reservations) {
                String line = toFileString(res);
                pw.println(line);
                System.out.println("Saving reservation: " + line);
            }
            pw.flush(); // Ensure everything is written
            System.out.println("Saved all reservations to: " + file.getAbsolutePath());
        } catch (IOException e) {
            System.err.println("Error saving reservations: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public static void addReservation(Reservation res) {
        // First add to in-memory list
        Main.reservationsList.add(res);
        System.out.println("Added reservation to memory: " + res);

        // Then save to file (appending)
        File file = FileUtils.getFile(FILE_NAME);

        try (PrintWriter pw = new PrintWriter(new FileOutputStream(file, true))) {
            String line = toFileString(res);
            pw.println(line);
            pw.flush(); // Ensure it's written
            System.out.println("Appended reservation to file: " + line);
            System.out.println("File path: " + file.getAbsolutePath());
        } catch (IOException e) {
            System.err.println("Error saving reservation: " + e.getMessage());
            e.printStackTrace();
        }

        // Verify file contents
        System.out.println("Verifying file contents:");
        ArrayList<Reservation> loaded = loadReservations();
        for (Reservation r : loaded) {
            System.out.println(" - " + r);
        }
    }

    public static ArrayList<Reservation> loadReservations() {
        ArrayList<Reservation> reservations = new ArrayList<>();
        File file = FileUtils.getFile(FILE_NAME);

        System.out.println("Loading reservations from: " + file.getAbsolutePath());
        System.out.println("File exists: " + file.exists());
        System.out.println("File size: " + file.length() + " bytes");

        if (file.length() == 0) {
            System.out.println("File is empty - no reservations to load");
            return reservations;
        }

        try (Scanner scanner = new Scanner(file)) {
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                if (line.trim().isEmpty()) continue;

                System.out.println("Reading line: " + line);

                String[] parts = line.split(",");
                if (parts.length >= 4) {
                    String username = parts[0];
                    String roomNumber = parts[1];
                    String dateTime = parts[2];
                    String status = parts[3];
                    String comment = parts.length >= 5 ? parts[4] : "";

                    User user = AccountManager.getUserByUsername(username);
                    Room room = Main.findRoomByNumber(roomNumber);

                    if (user != null && room != null) {
                        Reservation reservation = new Reservation(user, room, dateTime);
                        reservation.setStatus(status, comment);
                        reservations.add(reservation);
                        System.out.println("Loaded reservation: " + reservation);
                    } else {
                        System.err.println("Failed to load reservation: user=" + username + ", room=" + roomNumber);

                        // Auto-create missing user or room to avoid data loss
                        if (user == null) {
                            user = new User(username, "password", username, username + "@example.com");
                            Main.usersList.add(user);
                            System.out.println("Auto-created missing user: " + username);
                        }

                        if (room == null) {
                            // Default to Classroom if room type unknown
                            room = new Classroom(roomNumber, 30, "Unknown Location");
                            Main.roomsList.add(room);
                            System.out.println("Auto-created missing room: " + roomNumber);
                        }

                        // Now add the reservation
                        if (user != null && room != null) {
                            Reservation reservation = new Reservation(user, room, dateTime);
                            reservation.setStatus(status, comment);
                            reservations.add(reservation);
                            System.out.println("Added reservation after creating missing components: " + reservation);
                        }
                    }
                } else {
                    System.err.println("Invalid reservation format: " + line);
                }
            }
        } catch (IOException e) {
            System.err.println("Error loading reservations: " + e.getMessage());
            e.printStackTrace();
        }

        System.out.println("Loaded " + reservations.size() + " reservations from file");
        return reservations;
    }

    public static void updateReservationStatus(Reservation target, String status, String comment) {
        // Update in-memory list first
        boolean foundInMemory = false;
        for (Reservation res : Main.reservationsList) {
            if (res.matches(target)) {
                res.setStatus(status, comment);
                foundInMemory = true;
                System.out.println("Updated in-memory reservation: " + res);
                break;
            }
        }
        if (!foundInMemory) System.out.println("Reservation not found in memory to update");

        // Then update file
        ArrayList<Reservation> all = loadReservations();
        boolean foundInFile = false;
        for (Reservation res : all) {
            if (res.matches(target)) {
                res.setStatus(status, comment);
                foundInFile = true;
                System.out.println("Updated file reservation: " + res);
                break;
            }
        }
        if (!foundInFile) System.out.println("Reservation not found in file to update");

        saveAllReservations(all);
    }
}