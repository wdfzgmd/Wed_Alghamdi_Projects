import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

public class AdminLoginPage extends Application {
    @Override
    public void start(Stage stage) {
        stage.setTitle("Admin Login Page");

        GridPane grid = new GridPane();
        grid.setPadding(new Insets(10));
        grid.setVgap(10);
        grid.setHgap(10);

        TextField usernameField = new TextField();
        PasswordField passwordField = new PasswordField();
        Button loginButton = new Button("Login");

        grid.add(usernameField, 0, 0);
        grid.add(passwordField, 0, 1);
        grid.add(loginButton, 0, 2);

        loginButton.setOnAction(e -> {
            String username = usernameField.getText();
            String password = passwordField.getText();

            if ((username.equals("Wed") && password.equals("2028kfupmcoeics"))||(username.equals("Fatimah") && password.equals("12345"))||(username.equals("Layan") && password.equals("swe12345"))) {
                try {
                    AdminDashboardPage dashboard = new AdminDashboardPage();
                    dashboard.start(new Stage());
                    stage.close();
                } catch (Exception ex) {
                    System.out.println("An error occurred while opening the admin dashboard.");
                }
            } else {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setHeaderText(null);
                alert.setContentText("Incorrect admin username or password.");
                alert.showAndWait();
            }
        });

        Scene scene = new Scene(grid, 400, 200);
        stage.setScene(scene);
        stage.show();
    }
}


