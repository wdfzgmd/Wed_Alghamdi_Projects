import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class UserLoginPage extends Application {
    @Override
    public void start(Stage stage) {
        stage.setTitle("User Login Page");

        // Create a VBox for the main layout
        VBox mainLayout = new VBox(15);
        mainLayout.setPadding(new Insets(20));
        mainLayout.setAlignment(Pos.CENTER);

        // Title
        Text title = new Text("KFUPM's Room Reservation");
        title.setFont(Font.font("System", FontWeight.BOLD, 18));

        // Login form
        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setAlignment(Pos.CENTER);

        Label usernameLabel = new Label("Username:");
        TextField usernameField = new TextField();
        usernameField.setPrefWidth(200);

        Label passwordLabel = new Label("Password:");
        PasswordField passwordField = new PasswordField();
        passwordField.setPrefWidth(200);

        Button loginButton = new Button("Login");
        loginButton.setPrefWidth(200);

        // "Don't have an account?" message and sign up button
        Text signupMessage = new Text("Don't have an account?");

        Button signupButton = new Button("Sign Up");
        signupButton.setPrefWidth(200);

        // Back button to return to main menu
        Button backButton = new Button("Back to Main Menu");
        backButton.setPrefWidth(200);

        // Add controls to the grid
        grid.add(usernameLabel, 0, 0);
        grid.add(usernameField, 1, 0);
        grid.add(passwordLabel, 0, 1);
        grid.add(passwordField, 1, 1);

        // Create layout for buttons
        VBox buttonsBox = new VBox(10);
        buttonsBox.setAlignment(Pos.CENTER);
        buttonsBox.getChildren().addAll(loginButton, signupMessage, signupButton, backButton);

        // Add everything to the main layout
        mainLayout.getChildren().addAll(title, grid, buttonsBox);

        // Login action
        loginButton.setOnAction(e -> {
            String username = usernameField.getText();
            String password = passwordField.getText();

            if (Main.accountManager.authenticateFromFile(username, password)) {
                try {
                    UserReservationPage userPage = new UserReservationPage(username);
                    userPage.start(new Stage());
                    stage.close();
                } catch (Exception ex) {
                    System.out.println("An error occurred while opening the user page: " + ex.getMessage());
                    ex.printStackTrace();
                }
            } else {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setHeaderText(null);
                alert.setContentText("Incorrect username or password.");
                alert.showAndWait();
            }
        });

        // Sign up action
        signupButton.setOnAction(e -> {
            try {
                UserSignUpPage signUpPage = new UserSignUpPage();
                signUpPage.start(new Stage());
                stage.close();
            } catch (Exception ex) {
                System.out.println("An error occurred while opening the sign up page: " + ex.getMessage());
                ex.printStackTrace();
            }
        });

        // Back button action
        backButton.setOnAction(e -> {
            try {
                Main mainApp = new Main();
                mainApp.start(new Stage());
                stage.close();
            } catch (Exception ex) {
                System.out.println("An error occurred while returning to main menu: " + ex.getMessage());
                ex.printStackTrace();
            }
        });

        Scene scene = new Scene(mainLayout, 450, 400);
        stage.setScene(scene);
        stage.show();
    }
}