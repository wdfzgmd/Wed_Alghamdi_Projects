import java.util.Optional;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;

public class RoomManager {

    public static void addRoomDialog(TextArea roomInfoArea) {
        Dialog<Room> dialog = new Dialog<>();
        dialog.setTitle("Add New Room");

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);

        TextField numberField = new TextField();
        TextField capacityField = new TextField();
        TextField locationField = new TextField();
        ChoiceBox<String> typeChoice = new ChoiceBox<>();
        typeChoice.getItems().addAll("Classroom", "Lecture Hall", "Lab Room");
        typeChoice.setValue("Classroom");

        grid.add(new Label("Room Number:"), 0, 0);
        grid.add(numberField, 1, 0);
        grid.add(new Label("Capacity:"), 0, 1);
        grid.add(capacityField, 1, 1);
        grid.add(new Label("Location:"), 0, 2);
        grid.add(locationField, 1, 2);
        grid.add(new Label("Type:"), 0, 3);
        grid.add(typeChoice, 1, 3);

        dialog.getDialogPane().setContent(grid);
        dialog.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);

        // Focus on first field when dialog opens
        dialog.setOnShowing(e -> numberField.requestFocus());

        // Add validation before closing dialog
        Button okButton = (Button) dialog.getDialogPane().lookupButton(ButtonType.OK);
        okButton.addEventFilter(javafx.event.ActionEvent.ACTION, event -> {
            try {
                String number = numberField.getText().trim();
                String capacityText = capacityField.getText().trim();
                String location = locationField.getText().trim();

                // Validate room number
                if (number.isEmpty()) {
                    showErrorAlert("Room number cannot be empty");
                    event.consume();  // Prevent dialog from closing
                    return;
                }

                // Check if room number already exists
                for (Room existingRoom : Main.roomsList) {
                    if (existingRoom.getRoomNumber().equals(number)) {
                        showErrorAlert("A room with this number already exists");
                        event.consume();  // Prevent dialog from closing
                        return;
                    }
                }

                // Validate capacity
                int capacity;
                try {
                    capacity = Integer.parseInt(capacityText);
                    if (capacity <= 0) {
                        showErrorAlert("Room capacity must be greater than zero");
                        event.consume();  // Prevent dialog from closing
                        return;
                    }
                } catch (NumberFormatException ex) {
                    showErrorAlert("Capacity must be a valid number");
                    event.consume();  // Prevent dialog from closing
                    return;
                }

                // Validate location
                if (location.isEmpty()) {
                    showErrorAlert("Location cannot be empty");
                    event.consume();  // Prevent dialog from closing
                }
            } catch (Exception ex) {
                showErrorAlert("Error: " + ex.getMessage());
                event.consume();  // Prevent dialog from closing
            }
        });

        dialog.setResultConverter(button -> {
            if (button == ButtonType.OK) {
                try {
                    String number = numberField.getText().trim();
                    int capacity = Integer.parseInt(capacityField.getText().trim());
                    String location = locationField.getText().trim();
                    String type = typeChoice.getValue();

                    Room newRoom = null;
                    switch (type) {
                        case "Classroom": newRoom = new Classroom(number, capacity, location); break;
                        case "Lecture Hall": newRoom = new LectureHall(number, capacity, location); break;
                        case "Lab Room": newRoom = new LabRoom(number, capacity, location); break;
                    }

                    // Show confirmation dialog
                    if (newRoom != null && showAddConfirmationDialog(newRoom)) {
                        return newRoom;
                    } else {
                        return null;
                    }
                } catch (Exception ex) {
                    roomInfoArea.setText("Error: " + ex.getMessage());
                    return null;
                }
            }
            return null;
        });

        Optional<Room> result = dialog.showAndWait();
        result.ifPresent(room -> {
            Main.roomsList.add(room);
            refreshRoomList(roomInfoArea);

            // Show success message
            Alert success = new Alert(Alert.AlertType.INFORMATION);
            success.setTitle("Room Added");
            success.setHeaderText(null);
            success.setContentText("Room " + room.getRoomNumber() + " has been successfully added.");
            success.showAndWait();
        });
    }

    public static void editRoomDialog(TextArea roomInfoArea) {
        if (Main.roomsList.isEmpty()) {
            roomInfoArea.setText("No rooms available to edit");
            return;
        }

        ChoiceDialog<Room> selectDialog = new ChoiceDialog<>(Main.roomsList.get(0), Main.roomsList);
        selectDialog.setTitle("Edit Room");
        selectDialog.setHeaderText("Select a room to edit");

        Optional<Room> result = selectDialog.showAndWait();
        result.ifPresent(roomToEdit -> {
            Dialog<Boolean> editDialog = new Dialog<>();
            editDialog.setTitle("Edit Room");
            editDialog.setHeaderText("Editing: " + roomToEdit.getRoomNumber());

            GridPane grid = new GridPane();
            grid.setHgap(10);
            grid.setVgap(10);

            TextField numberField = new TextField(roomToEdit.getRoomNumber());
            numberField.setDisable(true);
            TextField capacityField = new TextField(String.valueOf(roomToEdit.getCapacity()));
            TextField locationField = new TextField(roomToEdit.getLocation());

            grid.add(new Label("Room Number:"), 0, 0);
            grid.add(numberField, 1, 0);
            grid.add(new Label("Capacity:"), 0, 1);
            grid.add(capacityField, 1, 1);
            grid.add(new Label("Location:"), 0, 2);
            grid.add(locationField, 1, 2);

            editDialog.getDialogPane().setContent(grid);
            editDialog.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);

            // Focus on capacity field when dialog opens
            editDialog.setOnShowing(e -> capacityField.requestFocus());

            // Add validation before closing dialog
            Button okButton = (Button) editDialog.getDialogPane().lookupButton(ButtonType.OK);
            okButton.addEventFilter(javafx.event.ActionEvent.ACTION, event -> {
                try {
                    String capacityText = capacityField.getText().trim();
                    String location = locationField.getText().trim();

                    // Validate capacity
                    int capacity;
                    try {
                        capacity = Integer.parseInt(capacityText);
                        if (capacity <= 0) {
                            showErrorAlert("Room capacity must be greater than zero");
                            event.consume();  // Prevent dialog from closing
                            return;
                        }
                    } catch (NumberFormatException ex) {
                        showErrorAlert("Capacity must be a valid number");
                        event.consume();  // Prevent dialog from closing
                        return;
                    }

                    // Validate location
                    if (location.isEmpty()) {
                        showErrorAlert("Location cannot be empty");
                        event.consume();  // Prevent dialog from closing
                    }
                } catch (Exception ex) {
                    showErrorAlert("Error: " + ex.getMessage());
                    event.consume();  // Prevent dialog from closing
                }
            });

            editDialog.setResultConverter(button -> {
                if (button == ButtonType.OK) {
                    try {
                        int newCapacity = Integer.parseInt(capacityField.getText().trim());
                        String newLocation = locationField.getText().trim();

                        // Show confirmation dialog with old and new values
                        if (showEditConfirmationDialog(roomToEdit, newCapacity, newLocation)) {
                            roomToEdit.setCapacity(newCapacity);
                            roomToEdit.setLocation(newLocation);
                            refreshRoomList(roomInfoArea);

                            // Show success message
                            Alert success = new Alert(Alert.AlertType.INFORMATION);
                            success.setTitle("Room Updated");
                            success.setHeaderText(null);
                            success.setContentText("Room " + roomToEdit.getRoomNumber() + " has been successfully updated.");
                            success.showAndWait();

                            return true;
                        }
                    } catch (Exception ex) {
                        roomInfoArea.setText("Error: " + ex.getMessage());
                    }
                }
                return false;
            });

            editDialog.showAndWait();
        });
    }

    public static void deleteRoomDialog(TextArea roomInfoArea) {
        if (Main.roomsList.isEmpty()) {
            roomInfoArea.setText("No rooms available to delete");
            return;
        }

        ChoiceDialog<Room> selectDialog = new ChoiceDialog<>(Main.roomsList.get(0), Main.roomsList);
        selectDialog.setTitle("Delete Room");
        selectDialog.setHeaderText("Select a room to delete");

        Optional<Room> result = selectDialog.showAndWait();
        result.ifPresent(room -> {
            // Check if room has any active reservations
            boolean hasReservations = false;
            for (Reservation res : Main.reservationsList) {
                if (res.getRoom().getRoomNumber().equals(room.getRoomNumber()) &&
                        (res.getStatus().equals("Pending") || res.getStatus().equals("Approved"))) {
                    hasReservations = true;
                    break;
                }
            }

            // Create a custom confirmation dialog
            Alert confirm = new Alert(Alert.AlertType.CONFIRMATION);
            confirm.setTitle("Confirm Deletion");
            confirm.setHeaderText("Are you sure you want to delete " + room.getRoomNumber() + "?");

            // Create content with warning
            VBox content = new VBox(10);
            Text warningText = new Text("Warning: This action cannot be undone!");
            warningText.setFont(Font.font("System", FontWeight.BOLD, 12));
            warningText.setStyle("-fx-fill: red;");

            Text detailsText = new Text(
                    "Room: " + room.getRoomNumber() + "\n" +
                            "Type: " + room.getClass().getSimpleName() + "\n" +
                            "Capacity: " + room.getCapacity() + "\n" +
                            "Location: " + room.getLocation()
            );

            content.getChildren().add(warningText);
            content.getChildren().add(detailsText);

            // Add warning about existing reservations if any
            if (hasReservations) {
                Text reservationWarning = new Text(
                        "This room has active reservations. Deleting it will impact " +
                                "these reservations and may cause scheduling conflicts."
                );
                reservationWarning.setStyle("-fx-fill: orange;");
                reservationWarning.setWrappingWidth(400);
                content.getChildren().add(reservationWarning);
            }

            confirm.getDialogPane().setContent(content);

            // Add custom buttons
            ButtonType deleteButton = new ButtonType("Delete", ButtonBar.ButtonData.OK_DONE);
            ButtonType cancelButton = new ButtonType("Cancel", ButtonBar.ButtonData.CANCEL_CLOSE);
            confirm.getButtonTypes().setAll(deleteButton, cancelButton);

            Optional<ButtonType> confirmResult = confirm.showAndWait();
            if (confirmResult.isPresent() && confirmResult.get() == deleteButton) {
                Main.roomsList.remove(room);
                refreshRoomList(roomInfoArea);

                // Show success message
                Alert success = new Alert(Alert.AlertType.INFORMATION);
                success.setTitle("Room Deleted");
                success.setHeaderText(null);
                success.setContentText("Room " + room.getRoomNumber() + " has been successfully deleted.");
                success.showAndWait();
            }
        });
    }

    private static void refreshRoomList(TextArea infoArea) {
        StringBuilder sb = new StringBuilder("=== Room List ===\n\n");
        for (Room room : Main.roomsList) {
            sb.append(room.getRoomNumber())
                    .append(" (").append(room.getClass().getSimpleName()).append(")\n")
                    .append("Capacity: ").append(room.getCapacity()).append("\n")
                    .append("Location: ").append(room.getLocation()).append("\n")
                    .append("--------------------\n");
        }
        infoArea.setText(sb.toString());
    }

    /**
     * Shows an error alert with the given message
     */
    private static void showErrorAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Input Error");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    /**
     * Shows a confirmation dialog for adding a new room
     * @return true if the user confirms, false otherwise
     */
    private static boolean showAddConfirmationDialog(Room room) {
        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION);
        confirm.setTitle("Confirm Room Addition");
        confirm.setHeaderText("Confirm Room Details");

        VBox content = new VBox(10);
        Text infoText = new Text(
                "Please confirm the details of the new room:\n\n" +
                        "Room Number: " + room.getRoomNumber() + "\n" +
                        "Type: " + room.getClass().getSimpleName() + "\n" +
                        "Capacity: " + room.getCapacity() + "\n" +
                        "Location: " + room.getLocation()
        );
        content.getChildren().add(infoText);

        confirm.getDialogPane().setContent(content);

        ButtonType addButton = new ButtonType("Add Room", ButtonBar.ButtonData.OK_DONE);
        ButtonType cancelButton = new ButtonType("Cancel", ButtonBar.ButtonData.CANCEL_CLOSE);
        confirm.getButtonTypes().setAll(addButton, cancelButton);

        Optional<ButtonType> result = confirm.showAndWait();
        return result.isPresent() && result.get() == addButton;
    }

    /**
     * Shows a confirmation dialog for editing a room
     * @return true if the user confirms, false otherwise
     */
    private static boolean showEditConfirmationDialog(Room room, int newCapacity, String newLocation) {
        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION);
        confirm.setTitle("Confirm Room Edit");
        confirm.setHeaderText("Confirm Changes to " + room.getRoomNumber());

        VBox content = new VBox(10);

        Text currentText = new Text("Current values:");
        currentText.setFont(Font.font("System", FontWeight.BOLD, 12));

        Text currentDetails = new Text(
                "Capacity: " + room.getCapacity() + "\n" +
                        "Location: " + room.getLocation() + "\n"
        );

        Text newText = new Text("\nNew values:");
        newText.setFont(Font.font("System", FontWeight.BOLD, 12));

        Text newDetails = new Text(
                "Capacity: " + newCapacity + "\n" +
                        "Location: " + newLocation + "\n"
        );

        content.getChildren().addAll(currentText, currentDetails, newText, newDetails);

        // If capacity decreased, add warning about potential conflicts
        if (newCapacity < room.getCapacity()) {
            Text warningText = new Text(
                    "\nWarning: Reducing room capacity may affect existing reservations."
            );
            warningText.setStyle("-fx-fill: orange;");
            content.getChildren().add(warningText);
        }

        confirm.getDialogPane().setContent(content);

        ButtonType saveButton = new ButtonType("Save Changes", ButtonBar.ButtonData.OK_DONE);
        ButtonType cancelButton = new ButtonType("Cancel", ButtonBar.ButtonData.CANCEL_CLOSE);
        confirm.getButtonTypes().setAll(saveButton, cancelButton);


        Optional<ButtonType> result = confirm.showAndWait();
        return result.isPresent() && result.get() == saveButton;
    }
}