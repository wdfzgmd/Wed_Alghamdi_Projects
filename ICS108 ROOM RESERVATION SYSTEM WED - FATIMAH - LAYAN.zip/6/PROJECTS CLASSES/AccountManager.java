import java.io.*;
import java.util.Scanner;

public class AccountManager {

    private static final String ourFile = "users.txt";

    public void registerUser(String username, String password, String name, String email) {
        File file = FileUtils.getFile(ourFile); //Creating an object of type File and associate it with text file to use later

        try (PrintWriter pw = new PrintWriter(new FileOutputStream(file, true))) {
            pw.println(username + "," + password + "," + name + "," + email);
            pw.flush();
            // It wrote each user. Each user in a seperated line
            // Also add to users list
            Main.usersList.add(new User(username, password, name, email));
            System.out.println("Registered new user: " + username);
            System.out.println("Saved to: " + file.getAbsolutePath());
        } catch (IOException e) {
            System.err.println("Error writing to users file: " + e.getMessage());
        }
    }

    public boolean authenticateFromFile(String username, String password) {
        // Step 1: It will check in the memory first
        // Step 2 : It will check in the text file
        for (UserAccount acc : Main.usersList) {
            if (acc.getUsername().equals(username) && acc.login(password)) {
                System.out.println("Authenticated user from memory: " + username);
                return true;
            }
        }


        File file = FileUtils.getFile(ourFile);

        try (Scanner scanner = new Scanner(file)) {
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                String[] parts = line.split(",");
                if (parts.length >= 2) {
                    if (parts[0].equals(username) && parts[1].equals(password)) {
                        System.out.println("Authenticated user from file: " + username);

                        // This is used when it is used in the file only not the memory. If this is the case
                        // It will add it to the memory
                        if (getUserByUsername(username) == null) {
                            String name = parts.length > 2 ? parts[2] : username;
                            String email = parts.length > 3 ? parts[3] : username + "@example.com";
                            Main.usersList.add(new User(username, password, name, email));
                            System.out.println("Added user from file to memory: " + username);
                        }

                        return true;
                    }
                }
            }
        } catch (IOException e) {
            System.err.println("Error reading users file: " + e.getMessage());
        }

        System.out.println("Authentication failed for: " + username);
        return false;
    }

    public void loadAllUsers() {
        File file = FileUtils.getFile(ourFile);

        if (file.length() == 0) {
            System.out.println("Users file is empty");
            return;
        }

        try (Scanner scanner = new Scanner(file)) {
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                String[] parts = line.split(",");
                if (parts.length >= 4) {
                    String username = parts[0];
                    String password = parts[1];
                    String name = parts[2];
                    String email = parts[3];

                    // Check if user already exists in memory
                    boolean exists = false;
                    for (UserAccount acc : Main.usersList) {
                        if (acc.getUsername().equals(username)) {
                            exists = true;
                            break;
                        }
                    }

                    if (!exists) {
                        Main.usersList.add(new User(username, password, name, email));
                        System.out.println("Loaded user from file: " + username);
                    }
                }
            }
        } catch (IOException e) {
            System.err.println("Error loading users: " + e.getMessage());
        }

        System.out.println("Loaded " + Main.usersList.size() + " users");
    }

    public static User getUserByUsername(String username) {
        for (UserAccount acc : Main.usersList) {
            if (acc.getUsername().equals(username)) {
                if (acc instanceof User) {
                    return (User) acc;
                }
            }
        }

        System.out.println("User not found in memory: " + username);
        return null;
    }
}

