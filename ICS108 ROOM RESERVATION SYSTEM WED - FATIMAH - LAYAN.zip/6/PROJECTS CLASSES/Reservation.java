
public class Reservation {
    private User user;
    private Room room;
    private String dateTime;
    private String status;
    private String comment;

    public Reservation(User user, Room room, String dateTime) {
        this.user = user;
        this.room = room;
        this.dateTime = dateTime;
        this.status = "Pending";
        this.comment = "";
    }

    public void setStatus(String status, String comment) {
        this.status = status;
        this.comment = comment;
    }
    public void setStatus(String status) {
        this.status = status;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public User getUser() {
        return user;
    }

    public Room getRoom() {
        return room;
    }

    public String getDateTime() {
        return dateTime;
    }

    public String getStatus() {
        return status;
    }

    public String getComment() {
        return comment;
    }

    public boolean matches(Reservation other) {
        return this.user.getUsername().equals(other.user.getUsername()) &&
                this.room.getRoomNumber().equals(other.room.getRoomNumber()) &&
                this.dateTime.equals(other.dateTime);
    }
}
