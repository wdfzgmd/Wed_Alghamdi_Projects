import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

import java.util.*;

public class AdminDashboardPage extends Application {

    @Override
    public void start(Stage stage) {
        stage.setTitle("Admin Dashboard");

        TabPane tabPane = new TabPane();

        // TAB 1: Room Management
        Tab roomsTab = new Tab("Room Management");
        VBox roomManagementBox = new VBox(10);
        roomManagementBox.setPadding(new Insets(15));

        Label roomHeader = new Label("Room Operations");
        roomHeader.setStyle("-fx-font-weight: bold; -fx-font-size: 14;");

        HBox roomButtons = new HBox(10);
        Button addRoomBtn = new Button("Add Room");
        Button editRoomBtn = new Button("Edit Room");
        Button deleteRoomBtn = new Button("Delete Room");
        Button viewRoomsBtn = new Button("Refresh Room List");
        roomButtons.getChildren().addAll(addRoomBtn, editRoomBtn, deleteRoomBtn, viewRoomsBtn);

        TextArea roomInfoArea = new TextArea();
        roomInfoArea.setEditable(false);
        roomInfoArea.setPrefHeight(200);

        roomManagementBox.getChildren().addAll(roomHeader, roomButtons, roomInfoArea);
        roomsTab.setContent(roomManagementBox);

        // TAB 2: Reservation Management
        Tab reservationsTab = new Tab("Reservation Management");
        VBox resManagementBox = new VBox(10);
        resManagementBox.setPadding(new Insets(15));

        Label resHeader = new Label("Reservation Operations");
        resHeader.setStyle("-fx-font-weight: bold; -fx-font-size: 14;");

        HBox filterButtons = new HBox(10);
        Button viewPendingBtn = new Button("Pending");
        Button viewApprovedBtn = new Button("Approved");
        Button viewRejectedBtn = new Button("Rejected");
        Button refreshBtn = new Button("Refresh");
        filterButtons.getChildren().addAll(viewPendingBtn, viewApprovedBtn, viewRejectedBtn, refreshBtn);

        ListView<String> resListView = new ListView<>();
        Label selectedLabel = new Label("Selected: None");
        Reservation[] selectedReservation = new Reservation[1];

        Button approveBtn = new Button("Approve");
        Button rejectBtn = new Button("Reject");

        resManagementBox.getChildren().addAll(resHeader, filterButtons, selectedLabel, resListView, approveBtn, rejectBtn);
        reservationsTab.setContent(resManagementBox);

        tabPane.getTabs().addAll(roomsTab, reservationsTab);

        // ========== Room Management Logic ==========
        viewRoomsBtn.setOnAction(e -> refreshRoomList(roomInfoArea));

        addRoomBtn.setOnAction(e -> RoomManager.addRoomDialog(roomInfoArea));
        editRoomBtn.setOnAction(e -> RoomManager.editRoomDialog(roomInfoArea));
        deleteRoomBtn.setOnAction(e -> RoomManager.deleteRoomDialog(roomInfoArea));

        // ========== Reservation Management Logic ==========
        // Load reservations when admin dashboard is opened
        ArrayList<Reservation> freshReservations = ReservationManager.loadReservations();
        System.out.println("Admin dashboard loaded " + freshReservations.size() + " reservations");

        // Update the in-memory list
        Main.reservationsList.clear();
        Main.reservationsList.addAll(freshReservations);

        viewPendingBtn.setOnAction(e -> showReservationsByStatus("Pending", resListView, selectedLabel, selectedReservation));
        viewApprovedBtn.setOnAction(e -> showReservationsByStatus("Approved", resListView, selectedLabel, selectedReservation));
        viewRejectedBtn.setOnAction(e -> showReservationsByStatus("Rejected", resListView, selectedLabel, selectedReservation));
        refreshBtn.setOnAction(e -> {
            // Reload reservations from file and refresh the view
            ArrayList<Reservation> refreshedReservations = ReservationManager.loadReservations();
            System.out.println("Admin refreshed reservations. Found " + refreshedReservations.size() + " reservations");

            Main.reservationsList.clear();
            Main.reservationsList.addAll(refreshedReservations);

            showReservationsByStatus("Pending", resListView, selectedLabel, selectedReservation);
        });

        approveBtn.setOnAction(e -> {
            if (selectedReservation[0] == null) {
                selectedLabel.setText("Select a reservation first");
                return;
            }
            if (!selectedReservation[0].getStatus().equals("Pending")) {
                selectedLabel.setText("Only pending reservations can be approved");
                return;
            }

            TextInputDialog dialog = new TextInputDialog();
            dialog.setTitle("Approval Comments");
            dialog.setHeaderText("Optional comments for approval");
            dialog.setContentText("Comments:");
            dialog.showAndWait().ifPresent(comment -> {
                selectedReservation[0].setStatus("Approved", comment);
                // Update the reservation in file system
                ReservationManager.updateReservationStatus(selectedReservation[0], "Approved", comment);
                selectedLabel.setText("Approved reservation.");
                showReservationsByStatus("Pending", resListView, selectedLabel, selectedReservation);
            });
        });

        rejectBtn.setOnAction(e -> {
            if (selectedReservation[0] == null) {
                selectedLabel.setText("Select a reservation first");
                return;
            }
            if (!selectedReservation[0].getStatus().equals("Pending")) {
                selectedLabel.setText("Only pending reservations can be rejected");
                return;
            }

            TextInputDialog dialog = new TextInputDialog();
            dialog.setTitle("Rejection Reason");
            dialog.setHeaderText("Required reason for rejection");
            dialog.setContentText("Reason:");
            dialog.showAndWait().ifPresent(reason -> {
                if (!reason.trim().isEmpty()) {
                    selectedReservation[0].setStatus("Rejected", reason.trim());
                    // Update the reservation in file system
                    ReservationManager.updateReservationStatus(selectedReservation[0], "Rejected", reason.trim());
                    selectedLabel.setText("Rejected reservation.");
                    showReservationsByStatus("Pending", resListView, selectedLabel, selectedReservation);
                } else {
                    selectedLabel.setText("Rejection reason required.");
                }
            });
        });

        // Initial UI load
        refreshRoomList(roomInfoArea);
        showReservationsByStatus("Pending", resListView, selectedLabel, selectedReservation);

        stage.setScene(new Scene(tabPane, 700, 500));
        stage.show();
    }

    private void refreshRoomList(TextArea infoArea) {
        StringBuilder sb = new StringBuilder("=== Room List ===\n\n");
        for (Room room : Main.roomsList) {
            sb.append(room.getRoomNumber())
                    .append(" (").append(room.getClass().getSimpleName()).append(")\n")
                    .append("Capacity: ").append(room.getCapacity()).append("\n")
                    .append("Location: ").append(room.getLocation()).append("\n")
                    .append("--------------------\n");
        }
        infoArea.setText(sb.toString());
    }

    private void showReservationsByStatus(String status, ListView<String> listView, Label selectedLabel, Reservation[] selectedReservation) {
        listView.getItems().clear();
        selectedReservation[0] = null;
        selectedLabel.setText("Selected: None");

        // Make sure we're using the latest reservations from file
        ArrayList<Reservation> currentReservations = ReservationManager.loadReservations();

        // Update in-memory list with latest data
        Main.reservationsList.clear();
        Main.reservationsList.addAll(currentReservations);

        System.out.println("Showing reservations with status: " + status);
        System.out.println("Total reservations: " + Main.reservationsList.size());

        int matchCount = 0;
        for (int i = 0; i < Main.reservationsList.size(); i++) {
            Reservation res = Main.reservationsList.get(i);
            System.out.println("Checking reservation " + i + ": " + res + " (Status: " + res.getStatus() + ")");

            if (res.getStatus().equals(status)) {
                matchCount++;
                String display = "[ID: " + i + "] User: " + res.getUser().getUsername()
                        + ", Room: " + res.getRoom().getRoomNumber()
                        + ", Time: " + res.getDateTime();
                listView.getItems().add(display);
                System.out.println("Added to list: " + display);
            }
        }

        System.out.println("Found " + matchCount + " reservations with status: " + status);

        listView.setOnMouseClicked(e -> {
            int index = listView.getSelectionModel().getSelectedIndex();
            if (index >= 0) {
                int realIndex = getNthReservationIndexByStatus(status, index);
                selectedReservation[0] = Main.reservationsList.get(realIndex);
                selectedLabel.setText("Selected: Reservation #" + realIndex);
            }
        });
    }

    private int getNthReservationIndexByStatus(String status, int n) {
        int count = -1;
        for (int i = 0; i < Main.reservationsList.size(); i++) {
            if (Main.reservationsList.get(i).getStatus().equals(status)) {
                count++;
                if (count == n) return i;
            }
        }
        return -1;
    }
}