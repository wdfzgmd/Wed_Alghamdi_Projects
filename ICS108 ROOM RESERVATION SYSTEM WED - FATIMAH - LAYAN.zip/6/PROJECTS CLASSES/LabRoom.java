public class LabRoom extends Room {
    public LabRoom(String roomNumber, int capacity, String location) {
        super(roomNumber, capacity, location);
        // It inherit all common features from Room
    }

    @Override
    public boolean isAvailable(int hour) {
        return hour >= 11 && hour < 16;
        // To ensure that Laboratory rooms are available only from 11am to 16am
    }
}