import java.io.File;
import java.io.IOException;

public class FileUtils {
    private static final String DATA_DIR = "classroom_reservation_data";

    public static File getDataDirectory() {
        File dataDir = new File(DATA_DIR);
        if (!dataDir.exists()) {
            if (dataDir.mkdir()) {
                System.out.println("Created data directory at: " + dataDir.getAbsolutePath());
            } else {
                System.err.println("Failed to create data directory at: " + dataDir.getAbsolutePath());
            }
        }
        return dataDir;
    }

    public static File getFile(String fileName) {
        File dataDir = getDataDirectory();
        File file = new File(dataDir, fileName);

        // Create the file if it doesn't exist
        if (!file.exists()) {
            try {
                file.createNewFile();
                System.out.println("Created new file: " + file.getAbsolutePath());
            } catch (IOException e) {
                System.err.println("Error creating file " + fileName + ": " + e.getMessage());
            }
        }

        return file;
    }
}