public class LectureHall extends Room {
    public LectureHall(String roomNumber, int capacity, String location) {
        super(roomNumber, capacity, location);
        // It also inherit all common features in Room class
    }

    @Override
    public boolean isAvailable(int hour) {
        return hour >= 7 && hour < 16;
        // To ensure that lecture halls are available only from 7am to 16am
    }
}