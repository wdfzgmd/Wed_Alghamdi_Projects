public class Classroom extends Room {
    public Classroom(String roomNumber, int capacity, String location) {
        super(roomNumber, capacity, location);
        // It inherit all common features from Room class
    }

    @Override
    public boolean isAvailable(int hour) {
        return true;
    }
}