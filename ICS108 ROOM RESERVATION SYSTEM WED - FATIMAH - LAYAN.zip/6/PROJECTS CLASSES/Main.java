import java.util.ArrayList;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

public class Main extends Application {
    public static AccountManager accountManager = new AccountManager();
    public static ArrayList<Room> roomsList = new ArrayList<>();
    public static ArrayList<Reservation> reservationsList = new ArrayList<>();
    public static ArrayList<UserAccount> usersList = new ArrayList<>();
    public static ReservationManager reservationManager = new ReservationManager();

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("KFUPM's Room Reservation");

        System.out.println("Starting application...");

        // Create data directory if it doesn't exist
        FileUtils.getDataDirectory();

        // Initialize rooms if not already added
        if (roomsList.isEmpty()) {
            roomsList.add(new Classroom("113", 20, "Building 7"));
            roomsList.add(new Classroom("116", 20, "Building 7"));
            roomsList.add(new Classroom("158", 20, "Building 24"));
            roomsList.add(new Classroom("163", 20, "Building 6"));
            roomsList.add(new Classroom("257", 20, "Building 6"));

            roomsList.add(new LabRoom("204", 15, "Building 6"));
            roomsList.add(new LabRoom("105", 15, "Building 75"));
            roomsList.add(new LabRoom("335", 35, "Building 22"));

            roomsList.add(new LectureHall("125", 70, "Building 6"));
            roomsList.add(new LectureHall("111", 35, "Building 14"));
            System.out.println("Added " + roomsList.size() + " rooms");
        }

        // Initialize users if not already loaded
        if (usersList.isEmpty()) {
            usersList.add(new User("user1", "pass1", "John Doe", "john@example.com"));
            usersList.add(new User("user2", "pass2", "Jane Smith", "jane@example.com"));
            System.out.println("Added initial users");

            // Load any additional users from file
            accountManager.loadAllUsers();
        }

        // Load reservations from file
        ArrayList<Reservation> loadedReservations = reservationManager.loadReservations();
        reservationsList.clear();
        reservationsList.addAll(loadedReservations);
        System.out.println("Loaded " + reservationsList.size() + " reservations");

        GridPane grid = new GridPane();
        grid.setPadding(new Insets(10));
        grid.setVgap(10);
        grid.setHgap(10);

        Button adminButton = new Button("Admin");
        Button userButton = new Button("User");

        grid.add(adminButton, 0, 0);
        grid.add(userButton, 1, 0);

        adminButton.setOnAction(e -> {
            // Go directly to the Admin Login page
            AdminLoginPage adminLogin = new AdminLoginPage();
            try {
                adminLogin.start(new Stage());
                primaryStage.close();
            } catch (Exception ex) {
                System.err.println("An error occurred while opening the Admin login page: " + ex.getMessage());
                ex.printStackTrace();
            }
        });

        userButton.setOnAction(e -> {
            // Go directly to the User Login page instead of the Main Page
            UserLoginPage userLoginPage = new UserLoginPage();
            try {
                userLoginPage.start(new Stage());
                primaryStage.close();
            } catch (Exception ex) {
                System.err.println("An error occurred while opening the User login page: " + ex.getMessage());
                ex.printStackTrace();
            }
        });

        Scene scene = new Scene(grid, 400, 200);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static Room findRoomByNumber(String roomNumber) {
        for (Room room : roomsList) {
            if (room.getRoomNumber().equals(roomNumber)) {
                return room;
            }
        }
        System.out.println("Room not found: " + roomNumber);
        return null;
    }

    public static void main(String[] args) {
        launch(args);
    }
}