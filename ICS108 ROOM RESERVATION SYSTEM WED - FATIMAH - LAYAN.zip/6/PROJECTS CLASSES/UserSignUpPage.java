import java.util.regex.Pattern;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;
public class UserSignUpPage extends Application {
    // Regular expression pattern for KFUPM email format: s(9-digit number)@kfupm.edu.sa
    private static final Pattern KFUPM_EMAIL_PATTERN =
            Pattern.compile("s\\d{9}@kfupm\\.edu\\.sa");

    @Override
    public void start(Stage stage) {
        stage.setTitle("User Sign Up Page");

        // Create a VBox for the main layout
        VBox mainLayout = new VBox(15);
        mainLayout.setPadding(new Insets(20));
        mainLayout.setAlignment(Pos.CENTER);

        // Title
        Text title = new Text("Create New Account");
        title.setFont(Font.font("System", FontWeight.BOLD, 18));

        GridPane grid = new GridPane();
        grid.setPadding(new Insets(10));
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setAlignment(Pos.CENTER);

        Label usernameLabel = new Label("Username:");
        TextField usernameField = new TextField();
        usernameField.setPrefWidth(250);

        Label passwordLabel = new Label("Password:");
        PasswordField passwordField = new PasswordField();
        passwordField.setPrefWidth(250);

        Label nameLabel = new Label("Full Name:");
        TextField nameField = new TextField();
        nameField.setPrefWidth(250);

        Label emailLabel = new Label("Email (s#########@kfupm.edu.sa):");
        TextField emailField = new TextField();
        emailField.setPrefWidth(250);
        emailField.setPromptText("sXXXXXXXXX@kfupm.edu.sa");

        Button signUpButton = new Button("Sign Up");
        signUpButton.setPrefWidth(250);

        Button backButton = new Button("Back to Login");
        backButton.setPrefWidth(250);

        grid.add(usernameLabel, 0, 0);
        grid.add(usernameField, 1, 0);
        grid.add(passwordLabel, 0, 1);
        grid.add(passwordField, 1, 1);
        grid.add(nameLabel, 0, 2);
        grid.add(nameField, 1, 2);
        grid.add(emailLabel, 0, 3);
        grid.add(emailField, 1, 3);

        // Add controls to layout
        mainLayout.getChildren().addAll(title, grid, signUpButton, backButton);

        signUpButton.setOnAction(e -> {
            String username = usernameField.getText();
            String password = passwordField.getText();
            String name = nameField.getText();
            String email = emailField.getText();

            // Validate all fields are filled
            if (username.isEmpty() || password.isEmpty() || name.isEmpty() || email.isEmpty()) {
                showAlert(Alert.AlertType.ERROR, "All fields are required!");
                return;
            }

            // Validate email format
            if (!isValidKfupmEmail(email)) {
                showAlert(Alert.AlertType.ERROR,
                        "Invalid email format! Please use the format: s#########@kfupm.edu.sa\n" +
                                "Example: s202344810@kfupm.edu.sa");
                return;
            }

            // Register user
            Main.accountManager.registerUser(username, password, name, email);

            showAlert(Alert.AlertType.INFORMATION, "User registered successfully!");

            try {
                UserReservationPage userPage = new UserReservationPage(username);
                userPage.start(new Stage());
                stage.close();
            } catch (Exception ex) {
                System.out.println("An error occurred while opening the user page: " + ex.getMessage());
                ex.printStackTrace();
            }
        });

        backButton.setOnAction(e -> {
            try {
                UserLoginPage loginPage = new UserLoginPage();
                loginPage.start(new Stage());
                stage.close();
            } catch (Exception ex) {
                System.out.println("An error occurred while opening the login page: " + ex.getMessage());
                ex.printStackTrace();
            }
        });

        Scene scene = new Scene(mainLayout, 500, 450);
        stage.setScene(scene);
        stage.show();
    }

    /**
     * Validates if the provided email matches the KFUPM format
     * @param email The email to validate
     * @return true if the email is valid, false otherwise
     */
    private boolean isValidKfupmEmail(String email) {
        if (email == null) {
            return false;
        }
        return KFUPM_EMAIL_PATTERN.matcher(email).matches();
    }

    /**
     * Shows an alert dialog with the given message
     * @param type The type of alert
     * @param message The message to display
     */
    private void showAlert(Alert.AlertType type, String message) {
        Alert alert = new Alert(type);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}