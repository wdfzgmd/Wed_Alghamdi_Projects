public abstract class Room {
    protected String roomNumber;
    protected int capacity;
    protected String location;

    public Room(String roomNumber, int capacity, String location) {
        if (roomNumber == null || roomNumber.trim().isEmpty()) {
            throw new IllegalArgumentException("Room number cannot be empty");
        }

        if (capacity <= 0) {
            throw new IllegalArgumentException("Room capacity must be greater than zero");
        }

        if (location == null || location.trim().isEmpty()) {
            throw new IllegalArgumentException("Location cannot be empty");
        }

        this.roomNumber = roomNumber;
        this.capacity = capacity;
        this.location = location;
    }

    public abstract boolean isAvailable(int hour);

    public String getRoomNumber() {
        return roomNumber;
    }

    public int getCapacity() {
        return capacity;
    }

    public String getLocation() {
        return location;
    }

    public void setCapacity(int newCapacity) {
        if (newCapacity <= 0) {
            throw new IllegalArgumentException("Room capacity must be greater than zero");
        }
        this.capacity = newCapacity;
    }

    public void setLocation(String newLocation) {
        if (newLocation == null || newLocation.trim().isEmpty()) {
            throw new IllegalArgumentException("Location cannot be empty");
        }
        this.location = newLocation;
    }

    @Override
    public String toString() {
        return roomNumber + " (" + getClass().getSimpleName() + ")";
    }
}