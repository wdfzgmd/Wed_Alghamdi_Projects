import java.util.ArrayList;

public class Admin extends UserAccount {

    public Admin(String username, String password, String name, String email) {
        super(username, password, name, email);
    }

    public void approveReservation(Reservation reservation, String comment) {
        reservation.setStatus("APPROVED", comment);
    }

    public void rejectReservation(Reservation reservation, String comment) {
        reservation.setStatus("REJECTED", comment);
    }

    public void addRoom(ArrayList<Room> rooms, Room newRoom) {
        rooms.add(newRoom);
    }

    public void deleteRoom(ArrayList<Room> rooms, Room roomToRemove) {
        rooms.remove(roomToRemove);
    }

    public void editRoom(Room room, int newCapacity, String newLocation) {
        room.capacity = newCapacity;
        room.location = newLocation;
    }
}